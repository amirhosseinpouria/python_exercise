a=int(input())
b=int(input())
c=int(input())
1<=a,b<=100
660<=c<=1439
latest_time=c-(a+b)
print(latest_time)