n=int(input())
for _ in range(n):
    name=input()
    print(f"Takk {name}")