a=int(input())
b=int(input())
if a>b:
    print("MAGA!")
elif a<b:
    print("FAKE NEWS!")
else:
    print("WORLD WAR 3!")