name=input()
age=int(input())
for _ in range(age):
    print(f"Hipp hipp hurra, {name}!")