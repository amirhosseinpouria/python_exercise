n=int(input())
rev=n/4
print(rev)