n=int(input())
m=int(input())
0<=m<=n<=10000
print(n-m)