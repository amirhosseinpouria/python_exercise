str1 = input()
char="u"
count=0
for i in str1:
    if i == char:
        count+=1
print(count)