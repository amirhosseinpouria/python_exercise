n=int(input())
k=int(input())
0<=n<=1000
passed_y=n//k
print(2022+passed_y)