n=int(input())
1<=n<=40
if n%10==0:
    print("Jebb")
else:
    print("Neibb")