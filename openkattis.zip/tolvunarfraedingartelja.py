n=int(input())
1<=n<=10**9
print(n-1)