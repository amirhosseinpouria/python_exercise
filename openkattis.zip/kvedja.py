sender_name=str(input())
print(f"Kvedja, \n {sender_name}")