dna=str(input())
if "COV" in dna:
    print("Veikur!")
else:
    print("Ekki veikur!")