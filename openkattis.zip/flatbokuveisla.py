n=int(input())
m=int(input())
1<=n,m<=10**6
print(n%m)