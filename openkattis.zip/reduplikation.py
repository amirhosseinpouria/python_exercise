word=str(input())
rep=int(input())
print(word*rep)