m=int(input())
1<=m<=12
if m==4 or m==6 or m==9 or m==11:
    print(30)
elif m==2:
    print(28)
else:
    print(31)
